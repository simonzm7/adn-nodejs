import { Controller, Post, Get, Put, Body, Res, Req, Param, UsePipes, ValidationPipe, Delete } from "@nestjs/common";
import { createAppointmentCase } from "src/application/Appointments/UseCases/createAppointmentCase";
import { AppointmentDTO } from "src/domain/Appointments/Repository/DTO/AppointmentDTO";
import { AppointmentSelectorDTo } from "src/domain/Appointments/Repository/DTO/AppointmentSelectorDTO";
import { Appointments } from "../DBEntities/appointment.entity";

@Controller('api/appointments')
export class AppointmentController {
   constructor(private readonly createAppointment: createAppointmentCase) { }
   @Get()
   async getAvailableAppointments(): Promise<Appointments[]> {
      return await this.createAppointment.ExecuteList();
   }
   @UsePipes(new ValidationPipe({ transform : true }))
   @Post()
   async create(@Body() appointment: AppointmentDTO, @Res() res, @Req() req) {
      const idDoctor: number = req.headers?.userid;
      if (idDoctor) appointment.idDoctor = idDoctor;
      const { code, message }: any = await this.createAppointment.ExecuteCreate(appointment);
      res.status(code).send(message);
   }
   @UsePipes(new ValidationPipe({ transform : true }))
   @Put()
   async selectAppointment(@Body() dto: AppointmentSelectorDTo, @Req() req, @Res() res) {

      const userId: number = req.headers?.userid;
      if (userId) dto.userId = userId;
      const { code, message }: any = await this.createAppointment.ExecuteSelector(dto);
      res.status(code).send(message);
   }
   @Put(':id')
   async cancelAppointment(@Param() param, @Req() req, @Res() res) {
      const { code, message }: any = await this.createAppointment.ExecuteCanceller(parseInt(param.id), req.headers.userid);
      res.status(code).send(message);
   }
   @Delete(':id')
   async deleteAppointment(@Param() param, @Req() req, @Res() res) {
      const { code, message }: any = await this.createAppointment.ExecuteDeletor(parseInt(param.id), req.headers.userid);
      res.status(code).send(message);
   }
}