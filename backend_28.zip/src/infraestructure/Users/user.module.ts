import { Module } from '@nestjs/common';
import { UserRegisterManagment } from 'src/application/Users/UseCases/UserRegisterManagment';
import { UserService } from 'src/domain/Users/services/UserService';
import { UserController } from './controllers/user.controller';
import { MergeProvider, MergeValidations, MergeDB } from './MergedProviders/MergeProvider';
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from './EntityManager/user.entity';
import { MergeExceptionRepository } from '../Exceptions/MergeProviders/MergeProviders';



@Module({
    imports: [TypeOrmModule.forFeature([User])],
    providers: [UserRegisterManagment, UserService,MergeProvider, MergeValidations, MergeDB],
    controllers: [UserController],
    exports: [MergeValidations, MergeDB]
})
export class UserModule {}