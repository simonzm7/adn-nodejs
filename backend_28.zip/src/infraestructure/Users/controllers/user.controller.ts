import { Controller, Post, Body, Res, Put, UsePipes, ValidationPipe } from '@nestjs/common';
import { UserRegisterManagment } from 'src/application/Users/UseCases/UserRegisterManagment';
import { UserDTO } from 'src/domain/Users/repositories/Users/DTO/UserDTO';

@Controller('api/user')
export class UserController {

    constructor(private readonly userManagment : UserRegisterManagment){}
    @UsePipes(new ValidationPipe({ transform : true }))
    @Post()
    async createUser(@Body() user : UserDTO, @Res() res)
    {
      const { code, message } : any = await this.userManagment.Execute(user);
      return res.status(code).send(message);
    }
}