export enum ActionType
{
    Take = 'tomada',
    Cancel = 'cancelada'
}