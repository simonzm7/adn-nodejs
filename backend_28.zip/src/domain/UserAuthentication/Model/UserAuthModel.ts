import { HttpStatus } from "@nestjs/common";
import ExceptionRepository from "src/domain/Exceptions/Repository/ExceptionRepository";
import LoginDTO from "../Repository/DTO/LoginDTO";

export default class UserAuthModel
{
    private credentials : LoginDTO;
    constructor(credentials : LoginDTO, private readonly userException : ExceptionRepository)   {
        this.credentials = credentials;
        const initialize : string[] = [
            this.Check('email').IsLength({min : 4, max: 30}),
            this.Check('email').IsEmail()
        ];
        const errors : string[] = this.validateInput(initialize);
        if(errors.length > 0)
            return this.userException.createException(errors, HttpStatus.BAD_REQUEST);
    }
    private validateInput = (config: string[]) => {
        const errors: string[] = [];
        config.forEach(v => {
            if (v) errors.push(v);
        });
        return errors;
    }
    private Check = (value: string) => {

        const validations = {
            IsEmail: () => {
                const emailRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                if (!(emailRegex.test(this.credentials[value]))) {
                    return 'Insert a valid email address';
                }
            },
            IsLength: (conditions: { min: number, max: number }) => {
                if (this.credentials[value].length < conditions.min)
                    return `The minimum ${value} length is ${conditions.min}`;
                if (this.credentials[value].length > conditions.max)
                    return `The maximum ${value} length is ${conditions.max}`;
            }
        }
        return validations;
    }
    get getEmail(): string {
        return this.credentials.email;
    }
    get getPassword(): string {
        return this.credentials.password;
    }
}