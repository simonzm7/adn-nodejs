export abstract class LoginRepository
{
    abstract LoginUser(userId : number)
}