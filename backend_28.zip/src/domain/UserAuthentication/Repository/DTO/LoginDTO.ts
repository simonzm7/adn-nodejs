import { IsString } from "class-validator";

export default class LoginDTO {
    @IsString()
    email : string;
    @IsString()
    password : string;
}