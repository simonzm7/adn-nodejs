import { HttpStatus, Injectable } from '@nestjs/common';
import { UserModel } from '../models/UserModel';
import { abstractUser } from '../repositories/Users/abstractUser';
import { ValidationsRepository } from '../repositories/Validations/ValidationsRepository';


@Injectable()
export class UserService {
  constructor(
    private readonly userRepository: abstractUser,
    private readonly userValidations: ValidationsRepository) { }

  public async Execute(user: UserModel) {

    if (!(await this.userValidations.UserAlreadyExists(user.get_email, user.get_dni))) {
      return await this.userRepository.createUser(user);
    }
      return {code: HttpStatus.BAD_REQUEST, message: 'User Already Exists'}
  }
}