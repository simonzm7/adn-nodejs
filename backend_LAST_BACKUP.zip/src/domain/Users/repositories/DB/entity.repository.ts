export abstract class EntityRepository {
    abstract create();
}