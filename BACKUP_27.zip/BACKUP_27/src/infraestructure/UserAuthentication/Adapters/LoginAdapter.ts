import { Injectable } from "@nestjs/common";
import CreateExceptionCase from "src/application/Exception/CreateExceptionCase";
import ExceptionRepository from "src/domain/Exceptions/Repository/ExceptionRepository";
import { LoginRepository } from "src/domain/UserAuthentication/Repository/LoginRepository";

@Injectable()
export class LoginAdapter implements LoginRepository{
    // Here constructor to provide token
    LoginUser = (userId : number) : {} => {
        return { data: {
            message: 'Sesion Iniciada',
            userId
        }, code: 200 };
    }
}