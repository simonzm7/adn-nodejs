import { HttpStatus, Injectable } from "@nestjs/common";
import CreateExceptionCase from "src/application/Exception/CreateExceptionCase";
import ExceptionRepository from "src/domain/Exceptions/Repository/ExceptionRepository";
import UserAuthModel from "src/domain/UserAuthentication/Model/UserAuthModel";
import { AuthValidationRepository } from "src/domain/UserAuthentication/Repository/AuthValidationRepository";

@Injectable()
export class ValidationsAdapter implements AuthValidationRepository {
    constructor(private readonly exceptionRepository: ExceptionRepository) { }
    validation = (credentials: UserAuthModel, password: string): boolean => {
        if (credentials.getPassword === password)
            return true;
        else
            return false;
    }
}