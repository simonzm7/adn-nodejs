import { Injectable, HttpStatus } from "@nestjs/common";
import { UserModel } from "src/domain/Users/models/UserModel";
import { abstractUser } from "src/domain/Users/repositories/Users/abstractUser";
import { InjectRepository } from "@nestjs/typeorm";
import { User } from "../EntityManager/user.entity";
import { Repository } from "typeorm";
import { DBAdapter } from "./DBAdapter";
import { DBRepository } from "src/domain/Users/repositories/DB/DBRepository";

@Injectable()
export class UserAdapter implements abstractUser {
    constructor(private readonly dbProvider : DBRepository){}//Change to DBRepository
    async createUser(user : UserModel){
        //console.log();
        const response = await this.dbProvider.CreateOne(user);
        //ER_DATA_TOO_LONG
        return await response;
    }
}