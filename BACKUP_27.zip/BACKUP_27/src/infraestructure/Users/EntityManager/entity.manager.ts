import { Injectable } from "@nestjs/common";
import { EntityRepository } from "src/domain/Users/repositories/DB/entity.repository";
import { EntityManager } from "typeorm";


@Injectable()
export class DBEntityManager implements EntityRepository{
    constructor(private readonly entityManager : EntityManager) {}
    create() 
    {
        this.entityManager.query("CREATE TABLE user (userId INT(255) AUTO_INCREMENT PRIMARY KEY,email VARCHAR(30) NOT NULL,password VARCHAR(30) NOT NULL,firstname VARCHAR(20) NOT NULL,lastname VARCHAR(20) NOT NULL,	dni VARCHAR(10) NOT NULL,role VARCHAR(8) NOT NULL)");
    }
}