import { Controller, Post, Get, Put, Body, Res, Req } from "@nestjs/common";
import { createAppointmentCase } from "src/application/Appointments/UseCases/createAppointmentCase";
import { AppointmentDTO } from "src/domain/Appointments/Repository/DTO/AppointmentDTO";
import { AppointmentSelectorDTo } from "src/domain/Appointments/Repository/DTO/AppointmentSelectorDTO";
import { Appointments } from "../DBEntities/appointment.entity";

@Controller('api/appointments')
export class AppointmentController {
    constructor(private readonly createAppointment : createAppointmentCase) {}
    //Implement UseGuard to check if the user is authenticated
   @Post()
   async create(@Body() appointment : AppointmentDTO, @Res() res, @Req() req) : Promise<{}>
   {
      const idDoctor : number = req.headers.userid;
       if(idDoctor)appointment.idDoctor = idDoctor;
      const {code, message} : any = await this.createAppointment.ExecuteCreate(appointment);
       return res.status(code).send(message);
   }
   @Get()
   async getAvailableAppointments() : Promise<Appointments[]>{
      return await this.createAppointment.ExecuteList();
   }

   @Put()
   async selectAppointment(@Body() dto : AppointmentSelectorDTo, @Req() req) {
      const userId : number = req.headers.userid;
       if(userId)dto.userId = userId;
      const {code, message} : any = await this.createAppointment.ExecuteSelector(dto);
      // Update Appointment { Status, idUser }
   }
}