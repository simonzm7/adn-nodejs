import { Module } from '@nestjs/common';
import { TypeOrmModule } from "@nestjs/typeorm";
import { createAppointmentCase } from 'src/application/Appointments/UseCases/createAppointmentCase';
import { AppointmentService } from 'src/domain/Appointments/Services/AppointmentService';
import { ExceptionModel } from '../Exceptions/exceptions.model';
import { UserModule } from '../Users/user.module';
import { AppointmentController } from './controllers/appointment.controller';
import { Appointments } from './DBEntities/appointment.entity';
import { MergeAdapter, MergeDBRepository, MergeValidations } from "./MergeProviders/mergeAppointment";
@Module({
    imports: [UserModule,ExceptionModel,TypeOrmModule.forFeature([Appointments])],
    controllers: [AppointmentController],
    providers: [createAppointmentCase,AppointmentService, MergeAdapter, MergeDBRepository, MergeValidations]
})
export class AppointmentModule {}