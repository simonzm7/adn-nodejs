import { HttpStatus, Injectable } from "@nestjs/common";
import { AppointmentModel } from "src/domain/Appointments/Model/AppointmentModel";
import { AppointmentDBRepository } from "src/domain/Appointments/Repository/AppointmentDBRepository";
import { InjectRepository } from "@nestjs/typeorm";
import { Appointments } from "../DBEntities/appointment.entity";
import { Repository } from "typeorm";


@Injectable()
export class AppointmentDBAdapter implements AppointmentDBRepository {
    constructor(@InjectRepository(Appointments) private readonly appointmentEntity : Repository<Appointments>) {}
    createAppointment = async (appointment: AppointmentModel): Promise<{}> => {
       //Verify if the doctor have an appointment on the same hour
       //Token provides tokenId to store on the db such as DoctorID
    //    const getDoctorId;
        
        const response = await this.appointmentEntity.save({
            idDoctor: appointment.getDoctorId,
            doctorname: appointment.doctorname,
            appointmentdate: appointment.appointmentDate,
            costappointment: appointment.cost,
            appointmentStatus: 0,
            IsFestive: appointment.IsFestive
        })
        .then(() => {return { code:  HttpStatus.OK, message: 'Cita Creada Correctamente' };})
        .catch((err) => {return { code:  HttpStatus.BAD_REQUEST, message: err };})
        return await response;
    }
    listAppointments = async () : Promise<Appointments[]> =>{ 
        const result =  await this.appointmentEntity.find({idUser: null});
        return result;
    }

    findAppointmentByIdAndStatus = async (idAppointment : number) : Promise<Appointments> => {
        return await this.appointmentEntity.findOne({idAppointment, appointmentStatus: 0});
    }

    putAppointment = async (appointment : Appointments, idUser : number) : Promise<{}> =>
    {
       appointment.appointmentStatus = 1;
       appointment.idUser = idUser;
       const response = this.appointmentEntity.save(appointment)
       .then(() => {
            return { code : HttpStatus.OK, message: 'Cita tomada correctamente' }
       }).catch(() => {
        return { code : HttpStatus.BAD_REQUEST, message: 'Error al tomar la cita' }
       })
      return response;   
    }
}