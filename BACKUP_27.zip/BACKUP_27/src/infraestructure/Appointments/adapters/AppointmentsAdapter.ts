import { Injectable } from "@nestjs/common";
import { AppointmentModel } from "src/domain/Appointments/Model/AppointmentModel";
import { AppointmentDBRepository } from "src/domain/Appointments/Repository/AppointmentDBRepository";
import { AppointmentRepository } from "src/domain/Appointments/Repository/AppointmentRepository";
import { Appointments } from "../DBEntities/appointment.entity";

@Injectable()
export class AppointmentAdapter implements AppointmentRepository{
    constructor(private readonly appoimentDBRepository : AppointmentDBRepository ) {}
    createAppointment = async (appointment : AppointmentModel) : Promise<{}> => {
        return await this.appoimentDBRepository.createAppointment(appointment);
    }
    listAppointments = async (parameters :{}) : Promise<Appointments[]> =>
    {
        return await this.appoimentDBRepository.listAppointments(parameters);
    }
    takeAppointment = async (appointment : Appointments, idUser : number) : Promise<{}> => {
        return await this.appoimentDBRepository.putAppointment(appointment, idUser);
    }
}