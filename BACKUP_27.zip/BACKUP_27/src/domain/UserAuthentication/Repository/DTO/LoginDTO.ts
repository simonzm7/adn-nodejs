export default class LoginDTO {
    email : string;
    password : string;
}