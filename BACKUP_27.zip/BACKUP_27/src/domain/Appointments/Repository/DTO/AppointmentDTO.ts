export class AppointmentDTO {

    idDoctor : number;
    doctorname : string;
    appointmentDate : any;
    cost : number;
    status : number;
    IsFestive : boolean
    idUser : number;
}