export class AppointmentSelectorDTo {
    AppointmentId : number;
    week : string;
    userId : number;
}