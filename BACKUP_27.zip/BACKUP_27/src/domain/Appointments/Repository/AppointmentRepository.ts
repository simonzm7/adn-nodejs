import { Appointments } from "src/infraestructure/Appointments/DBEntities/appointment.entity";
import { AppointmentModel } from "../Model/AppointmentModel";


export abstract class AppointmentRepository
{
    abstract createAppointment(appointment : AppointmentModel) : Promise<{}>;
    abstract listAppointments(parameters :{}) : Promise<Appointments[]>;
    abstract takeAppointment(appointment : Appointments, idUser : number) : Promise<{}>
}