import { Appointments } from "src/infraestructure/Appointments/DBEntities/appointment.entity";
import { AppointmentModel } from "../Model/AppointmentModel";


export abstract class AppointmentDBRepository
{
    abstract createAppointment(appointment : AppointmentModel) : Promise<{}>;
    abstract listAppointments(parameters : {}) : Promise<Appointments[]>;
    abstract findAppointmentByIdAndStatus(idAppointment : number) : Promise<Appointments>;
    abstract putAppointment(appointment : any, idUser : number) : Promise<{}>;
}