import { HttpStatus, Injectable } from "@nestjs/common";
import ExceptionRepository from "src/domain/Exceptions/Repository/ExceptionRepository";
import { Appointments } from "src/infraestructure/Appointments/DBEntities/appointment.entity";
import { Repository } from "typeorm";
import { AppointmentModel } from "../Model/AppointmentModel";
import { AppointmentSelectorModel } from "../Model/AppointmentSelectorModel";
import { AppointmentRepository } from "../Repository/AppointmentRepository";
import { AppointmentValidationRepository } from "../Repository/AppointmentValidationRepository";
import { AppointmentSelectorDTo } from "../Repository/DTO/AppointmentSelectorDTO";


@Injectable()
export class AppointmentService {
    constructor(
        private readonly appointmentRepository: AppointmentRepository,
        private readonly verifyAppointment: AppointmentValidationRepository,
        private readonly exceptionRepository: ExceptionRepository
    ) { }

    ExecuteCreate = async (appointment: AppointmentModel): Promise<{}> => {
        if (!(await this.verifyAppointment.VerifyIfDoctorHaveAppointment(appointment.getDoctorId, appointment.DateTime))) { //Must return false
            if (await this.verifyAppointment.VerifyRole(appointment.getDoctorId)) // Must return true
                return await this.appointmentRepository.createAppointment(appointment);
            else
                this.exceptionRepository.createException('No puedes crear una cita', HttpStatus.UNAUTHORIZED);
        } else
            this.exceptionRepository.createException('Solo puedes crear una cita cada hora', HttpStatus.BAD_REQUEST);
    }
    ExecuteList = async (): Promise<Appointments[]> => {
        return await this.appointmentRepository.listAppointments({});
    }

    ExecuteSelector = async (selectorModel : AppointmentSelectorModel): Promise<{}> => {
        const appointment : any = await this.verifyAppointment.VerifyAppointmentStatus(selectorModel.getAppointmentId, selectorModel.getAppointmentDate);
        if(appointment && typeof(appointment.costappointment) === 'number')
        {
            const userDNI : string | boolean = await this.verifyAppointment.VerifyIfCustomerHaveBalance(selectorModel.getUserId, appointment.costappointment);
            if(userDNI && typeof(userDNI) === 'string')
            {
                if(this.verifyAppointment.VerifyDNI(userDNI, selectorModel.getWeekDay))
                {
                    return this.appointmentRepository.takeAppointment(appointment, selectorModel.getUserId);
                }
                else{
                this.exceptionRepository.createException('No te encuentras en día pico y cédula', HttpStatus.BAD_REQUEST);
                }
            }
            else
            this.exceptionRepository.createException('No tienes saldo disponible', HttpStatus.BAD_REQUEST);
        }
        else
        this.exceptionRepository.createException('La cita no se encuentra disponible', HttpStatus.BAD_REQUEST);
        return {code: 200, message: 'Verifying...'};
    }
}