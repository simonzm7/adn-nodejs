import { UserModel } from "../../models/UserModel";

export abstract class abstractUser
{
    abstract createUser(user : UserModel) : Promise<{}>;
}