export class UserDTO {
    email : string;
    password : string;
    firstname : string;
    lastname : string;
    dni : string;
    role : string;
}