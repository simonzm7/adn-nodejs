import * as request from 'supertest';
import { createSandbox, SinonStubbedInstance } from "sinon";
import { Test } from "@nestjs/testing";
import { createStubObj } from 'test/util/createObjectStub';
import { Appointments } from 'src/infraestructure/Appointments/DBEntities/appointment.entity';
import { HttpStatus, INestApplication } from "@nestjs/common";
import { AppointmentRepository } from "src/domain/Appointments/Repository/AppointmentRepository";
import { AppointmentController } from "src/infraestructure/Appointments/controllers/appointment.controller";
import { createAppointmentCase } from "src/application/Appointments/UseCases/createAppointmentCase";
import { AppointmentService } from 'src/domain/Appointments/Services/AppointmentService';
import { AppointmentValidationRepository } from 'src/domain/Appointments/Repository/AppointmentValidationRepository';
import { ExceptionModel } from 'src/infraestructure/Exceptions/exceptions.model';
import { AppointmentDTO } from 'src/domain/Appointments/Repository/DTO/AppointmentDTO';
const sinonSandbox = createSandbox();

describe('AppointmentController', () => {
    let app: INestApplication;
    let appointmentRepository: SinonStubbedInstance<AppointmentRepository>;
    let appointmentValidationRepository: SinonStubbedInstance<AppointmentValidationRepository>;
    beforeAll(async () => {
        appointmentRepository = createStubObj<AppointmentRepository>(['createAppointment', 'listAppointments'], sinonSandbox);
        appointmentValidationRepository = createStubObj<AppointmentValidationRepository>(['VerifyIfDoctorHaveAppointment', 'VerifyRole'], sinonSandbox);
        const moduleRef = await Test.createTestingModule({
            imports: [ExceptionModel],
            controllers: [AppointmentController],
            providers: [createAppointmentCase,
                AppointmentService,
                { provide: AppointmentRepository, useValue: appointmentRepository },
                { provide: AppointmentValidationRepository, useValue: appointmentValidationRepository }]
        }).compile();

        app = moduleRef.createNestApplication();
        await app.init();
    });
    afterEach(() => sinonSandbox.restore());
    afterAll(async () => await app.close());
    it('It should get appointments list', async () => {
        const appoitmentsList: Appointments[] = [{ idAppointment: 1, idDoctor: 1, doctorname: "Juan Zapata", appointmentdate: "2020-12-28 07:00:00.000", costappointment: 80500, appointmentStatus: 0, IsFestive: false, idUser: null }];
        appointmentRepository.listAppointments.returns(Promise.resolve(appoitmentsList));

        return await request(app.getHttpServer())
            .get('/api/appointments')
            .expect(HttpStatus.OK)
            .expect(appoitmentsList);
    });
    it('It should be fail if the doctor have an appointment on the same hour', async () => {

        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(true));
        const appointment: AppointmentDTO = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);

        expect(response.body.message).toEqual('Solo puedes crear una cita cada hora');
    });
    it('It should be fail if the role is a Customer', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: AppointmentDTO = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.UNAUTHORIZED);

        expect(response.body.message).toEqual('No puedes crear una cita');
    });
    it('It should be fail if the doctorname not is a string only', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: AppointmentDTO = {
            idDoctor: 1,
            doctorname: 'Juan Zapata@',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body).toEqual(["El doctorname debe ser solo texto"]);
    });
    it('It should be fail if the appointment Date not is specific format', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: AppointmentDTO = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '000/29/11/2020/8:00:00',
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body.message).toEqual("Formato de fecha invalido");
    });

    it('It should be fail if the cost not is numeric only', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: any = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: '@80500',
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body).toEqual(["El cost debe ser solo numérico"]);
    });

    it('It should be fail if the cost is higher to 1000000', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: any = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 2000000,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body).toEqual(["El precio maximo del cost es 1000000"]);
    });

    it('It should be fail if the cost is less to 0', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: any = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: -10,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);

        const errorsList: string[] = [
            "El cost debe ser solo numérico",
            "El precio minimo del cost es 0"
        ];
        expect(response.body).toEqual(errorsList);
    });

    it('It should be fail if the status not is numeric only', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: any = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 80500,
            status: '0@',
            IsFestive: false,
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body).toEqual(["El status debe ser solo numérico"]);
    });
    it('It should be fail if IsFestive not is boolean only', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment: any = {
            idDoctor: 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '29/11/2020/8:00:00',
            cost: 80500,
            status: 0,
            IsFestive: '@false',
            idUser: null
        }
        const response = await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
        expect(response.body).toEqual(["El IsFestive debe ser solo booleano"]);
    });

    it('It should be fail if is Sunday', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment : any = {
            idDoctor : 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '27/11/2020/11:00:00', // Real calendar
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response =  await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
         expect(response.body).toEqual(["No puedes crear una cita el dia Domingo"]);
    });

    it('It should be fail if is not is working hours', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment : any = {
            idDoctor : 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '28/11/2020/6:00:00',
            cost: 80500,
            status: 0,
            IsFestive: false,
            idUser: null
        }
        const response =  await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
         expect(response.body).toEqual(["No puedes crear citas en este horario"]);
    });

    it('It should be fail if is festive and  not is working hours', async () => {
        appointmentValidationRepository.VerifyIfDoctorHaveAppointment.returns(Promise.resolve(false));
        appointmentValidationRepository.VerifyRole.returns(Promise.resolve(false));
        const appointment : any = {
            idDoctor : 1,
            doctorname: 'Juan Zapata',
            appointmentDate: '28/11/2020/7:00:00',
            cost: 80500,
            status: 0,
            IsFestive: true,
            idUser: null
        }
        const response =  await request(app.getHttpServer())
            .post('/api/appointments').send(appointment)
            .expect(HttpStatus.BAD_REQUEST);
         expect(response.body).toEqual(["No puedes crear citas en este horario"]);
    });
});



