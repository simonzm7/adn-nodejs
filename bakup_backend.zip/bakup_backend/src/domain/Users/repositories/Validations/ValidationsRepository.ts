export abstract class ValidationsRepository
{
    public abstract UserAlreadyExists(email : string, dni : string) : Promise<boolean>
}