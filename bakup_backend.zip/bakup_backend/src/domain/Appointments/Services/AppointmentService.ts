import { Injectable } from "@nestjs/common";
import { Appointments } from "src/infraestructure/Appointments/DBEntities/appointment.entity";
import { Repository } from "typeorm";
import { AppointmentModel } from "../Model/AppointmentModel";
import { AppointmentRepository } from "../Repository/AppointmentRepository";


@Injectable()
export class AppointmentService {
    constructor(
        private readonly appointmentRepository : AppointmentRepository
    ) {}

    ExecuteCreate = async (appointment : AppointmentModel ) : Promise<{}> => {
        return await this.appointmentRepository.createAppointment(appointment);
    }
    ExecuteList = async () : Promise<Appointments[]> => {
        return await this.appointmentRepository.listAppointments();
    }
}