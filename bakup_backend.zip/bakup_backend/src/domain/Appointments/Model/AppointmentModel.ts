import { AppointmentDTO } from "../Repository/DTO/AppointmentDTO";

export class AppointmentModel {

    private readonly appointment : AppointmentDTO;
    constructor(appointment : AppointmentDTO)
    {
        this.appointment = appointment;
    }

    get doctorname() : string {
        return this.appointment.doctorname;
    }

    get appointmentDate() : string {
        return this.appointment.appointmentDate;
    }
    get cost() : string {
        return this.appointment.cost;
    }
    get status() : string {
        return this.appointment.cost;
    }
}