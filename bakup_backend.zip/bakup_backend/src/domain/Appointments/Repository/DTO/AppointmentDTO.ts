export class AppointmentDTO {

    doctorname : string;
    appointmentDate : string;
    cost : string;
    status : string;
    idUser : string;
}