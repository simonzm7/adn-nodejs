import { Appointments } from "src/infraestructure/Appointments/DBEntities/appointment.entity";
import { AppointmentModel } from "../Model/AppointmentModel";


export abstract class AppointmentRepository
{
    abstract createAppointment(appointment : AppointmentModel) : Promise<{}>;
    abstract listAppointments() : Promise<Appointments[]>
}