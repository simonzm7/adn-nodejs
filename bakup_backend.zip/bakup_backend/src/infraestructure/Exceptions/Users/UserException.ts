import { HttpException, Injectable } from "@nestjs/common";

@Injectable()
export class UserException{
     
    public createException(message : any, statusCode : number)
    {
        throw new HttpException(message, statusCode);
    }
}