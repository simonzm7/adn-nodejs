import { Module } from '@nestjs/common';
import { UserRegisterManagment } from 'src/application/Users/UseCases/UserRegisterManagment';
import { UserService } from 'src/domain/Users/services/UserService';
import { UserController } from './controllers/user.controller';
import { MergeProvider, MergeValidations, MergeDB } from './MergedProviders/MergeProvider';
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from './EntityManager/user.entity';
import { DBEntityManager } from './EntityManager/entity.manager';
import { DBAdapter } from './adapters/DBAdapter';
import { UserException } from '../Exceptions/Users/UserException';



@Module({
    imports: [TypeOrmModule.forFeature([User])],
    providers: [UserRegisterManagment, UserService, DBEntityManager,DBAdapter,UserException ,MergeProvider, MergeValidations, MergeDB],
    controllers: [UserController],
})
export class UserModule {}