import { Controller, Post, Get, Body } from "@nestjs/common";
import { createAppointmentCase } from "src/application/Appointments/UseCases/createAppointmentCase";
import { AppointmentDTO } from "src/domain/Appointments/Repository/DTO/AppointmentDTO";
import { Appointments } from "../DBEntities/appointment.entity";

@Controller('api/appointments')
export class AppointmentController {
    constructor(private readonly createAppointment : createAppointmentCase) {}
   @Post()
   async create(@Body() appointment : AppointmentDTO) : Promise<{}>
   {
      return await this.createAppointment.ExecuteCreate(appointment);
   }

   @Get()
   async getAvailableAppointments() : Promise<Appointments[]>{
      return await this.createAppointment.ExecuteList();
   }
}