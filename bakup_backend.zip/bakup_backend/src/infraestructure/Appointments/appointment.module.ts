import { Module } from '@nestjs/common';
import { TypeOrmModule } from "@nestjs/typeorm";
import { createAppointmentCase } from 'src/application/Appointments/UseCases/createAppointmentCase';
import { AppointmentService } from 'src/domain/Appointments/Services/AppointmentService';
import { AppointmentController } from './controllers/appointment.controller';
import { Appointments } from './DBEntities/appointment.entity';
import { MergeAdapter, MergeDBRepository } from "./MergeProviders/mergeAppointment";
@Module({
    imports: [TypeOrmModule.forFeature([Appointments])],
    controllers: [AppointmentController],
    providers: [createAppointmentCase,AppointmentService, MergeAdapter, MergeDBRepository]
})
export class AppointmentModule {}