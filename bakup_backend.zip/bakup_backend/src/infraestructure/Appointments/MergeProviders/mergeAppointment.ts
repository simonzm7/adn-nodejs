import { AppointmentDBRepository } from "src/domain/Appointments/Repository/AppointmentDBRepository";
import { AppointmentRepository } from "src/domain/Appointments/Repository/AppointmentRepository";
import { AppointmentDBAdapter } from "../adapters/AppointmentDBAdapter";
import { AppointmentAdapter } from "../adapters/AppointmentsAdapter";


export const MergeAdapter = {
    provide: AppointmentRepository,
    useClass: AppointmentAdapter
}

export const MergeDBRepository = {
    provide: AppointmentDBRepository,
    useClass: AppointmentDBAdapter
}