import { HttpStatus, Injectable } from "@nestjs/common";
import { AppointmentModel } from "src/domain/Appointments/Model/AppointmentModel";
import { AppointmentDBRepository } from "src/domain/Appointments/Repository/AppointmentDBRepository";
import { InjectRepository } from "@nestjs/typeorm";
import { Appointments } from "../DBEntities/appointment.entity";
import { Repository } from "typeorm";


@Injectable()
export class AppointmentDBAdapter implements AppointmentDBRepository {
    constructor(@InjectRepository(Appointments) private readonly appointmentEntity : Repository<Appointments>) {}
    createAppointment = async (appointment: AppointmentModel): Promise<{}> => {
        const response = await this.appointmentEntity.save({
            doctorname: appointment.doctorname,
            appointmentdate: appointment.appointmentDate,
            costappointment: appointment.cost,
            appointmentStatus: appointment.status
        })
        .then(() => {return { code:  HttpStatus.OK, message: 'Cita Creada Correctamente' };})
        .catch((err) => {return { code:  HttpStatus.INTERNAL_SERVER_ERROR, message: err };})
        return await response;
    }
    listAppointments = async () : Promise<Appointments[]> =>{ 
        const result = await this.appointmentEntity.find();
        console.log(result);
        return result;
    }
}