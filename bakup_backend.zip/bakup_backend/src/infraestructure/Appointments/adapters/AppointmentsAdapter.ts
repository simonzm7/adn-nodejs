import { Injectable } from "@nestjs/common";
import { AppointmentModel } from "src/domain/Appointments/Model/AppointmentModel";
import { AppointmentDBRepository } from "src/domain/Appointments/Repository/AppointmentDBRepository";
import { Appointments } from "../DBEntities/appointment.entity";

@Injectable()
export class AppointmentAdapter implements AppointmentDBRepository{
    constructor(private readonly appoimentDBRepository : AppointmentDBRepository ) {}
    createAppointment = async (appointment : AppointmentModel) : Promise<{}> => {
        return await this.appoimentDBRepository.createAppointment(appointment);
    }
    listAppointments = async () : Promise<Appointments[]> =>
    {
        return await this.appoimentDBRepository.listAppointments();
    }
}