import {Entity,Column, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Appointments{

    @PrimaryGeneratedColumn()
    idAppointment : number;

    @Column()
    doctorname : string;

    @Column()
    appointmentdate : string;

    @Column()
    costappointment : string;

    @Column()
    appointmentStatus : string;

    @Column()
    idUser : string;

}