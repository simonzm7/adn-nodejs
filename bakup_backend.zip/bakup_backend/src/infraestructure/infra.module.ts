import { Module } from '@nestjs/common';
import { UserModule } from './Users/user.module';
import { TypeOrmModule } from "@nestjs/typeorm";
import { User } from './Users/EntityManager/user.entity';
import { AppointmentModule } from './Appointments/appointment.module';
import { Appointments } from './Appointments/DBEntities/appointment.entity';
@Module({
    imports:[AppointmentModule, UserModule, TypeOrmModule.forRoot({
        type: 'mysql',
        host: 'localhost',
        port: 3306,
        username: 'root',
        password: 'password',
        database: 'adndb',
        entities: [User, Appointments],
      })]
})
export class InfraestructureModel{}