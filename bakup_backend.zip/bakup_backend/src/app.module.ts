import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InfraestructureModel } from './infraestructure/infra.module';
import { User } from './infraestructure/Users/EntityManager/user.entity';
import { UserModule } from './infraestructure/Users/user.module';

@Module({
  imports: [UserModule, InfraestructureModel]
})
export class AppModule { }
